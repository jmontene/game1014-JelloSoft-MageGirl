# game1014-JelloSoft-MageGirl
Fantasy/2d Side Scrolling/Shooter


Inspirations: Contra, Metroid(NES),Castlevania

## Game Overview
A 2d platformer/shooter hybrid with a fantasy setting, with a female protagonist
